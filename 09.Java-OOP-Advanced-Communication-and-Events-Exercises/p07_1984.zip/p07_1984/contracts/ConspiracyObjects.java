package p07_1984.contracts;

public interface ConspiracyObjects {

    String getId();
}
