package panzer.contracts;

public interface Modelable {
    String getModel();
}
