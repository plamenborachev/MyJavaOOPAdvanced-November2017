package panzer.contracts;

public interface HitPointsModifyingPart extends Part {
    int getHitPointsModifier();
}
