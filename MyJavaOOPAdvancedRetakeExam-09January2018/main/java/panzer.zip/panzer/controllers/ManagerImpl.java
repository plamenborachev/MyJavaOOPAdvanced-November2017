package panzer.controllers;

import panzer.contracts.Manager;

import java.util.List;

public class ManagerImpl implements Manager {
    @Override
    public String addVehicle(List<String> arguments) {
        return null;
    }

    @Override
    public String addPart(List<String> arguments) {
        return null;
    }

    @Override
    public String inspect(List<String> arguments) {
        return null;
    }

    @Override
    public String battle(List<String> arguments) {
        return null;
    }

    @Override
    public String terminate(List<String> arguments) {
        return null;
    }
}
