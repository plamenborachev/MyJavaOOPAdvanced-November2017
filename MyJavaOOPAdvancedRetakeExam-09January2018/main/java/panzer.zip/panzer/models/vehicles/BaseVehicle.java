package panzer.models.vehicles;

import panzer.contracts.Part;
import panzer.contracts.Vehicle;

import java.math.BigDecimal;

public abstract class BaseVehicle implements Vehicle {

    private String model;
    private double weight;
    private BigDecimal price;
    private int attack;
    private int defense;
    private int hitPoints;

    protected BaseVehicle(String model, double weight, BigDecimal price, int attack, int defense, int hitPoints) {
        this.model = model;
        this.setWeight(weight);
        this.setPrice(price);
        this.setAttack(attack);
        this.setDefense(defense);
        this.setHitPoints(hitPoints);
    }

    protected void setWeight(double weight) {
        this.weight = weight;
    }

    protected void setPrice(BigDecimal price) {
        this.price = price;
    }

    protected void setAttack(int attack) {
        this.attack = attack;
    }

    protected void setDefense(int defense) {
        this.defense = defense;
    }

    protected void setHitPoints(int hitPoints) {
        this.hitPoints = hitPoints;
    }

    @Override
    public String getModel() {
        return null;
    }

    @Override
    public double getTotalWeight() {
        return 0;
    }

    @Override
    public BigDecimal getTotalPrice() {
        return this.price;
    }

    @Override
    public long getTotalAttack() {
        return 0;
    }

    @Override
    public long getTotalDefense() {
        return 0;
    }

    @Override
    public long getTotalHitPoints() {
        return 0;
    }

    @Override
    public void addArsenalPart(Part arsenalPart) {

    }

    @Override
    public void addShellPart(Part shellPart) {

    }

    @Override
    public void addEndurancePart(Part endurancePart) {

    }

    @Override
    public Iterable<Part> getParts() {
        return null;
    }
}
