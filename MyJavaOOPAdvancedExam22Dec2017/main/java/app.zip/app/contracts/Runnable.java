package app.contracts;

public interface Runnable {

    void run();
}
