package p04Тelephony;

public interface Callable {
    String call();
}
