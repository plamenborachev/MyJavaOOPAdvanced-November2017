package p04Тelephony;

public interface Browsable {
    String browse();
}
