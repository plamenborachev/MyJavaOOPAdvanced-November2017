package p08MilitaryElite;

public interface Spy extends Soldier {
    String getCodeNumber();
}
