package p08MilitaryElite;

public interface Soldier {
    Integer getId();
    String getFirstName();
    String getLastName();
}
