package p08MilitaryElite;

public interface Private extends Soldier {
    Double getSalary();
}
