package p08MilitaryElite;

public interface SpecialisedSoldier extends Private {
    String getCorps();
}
