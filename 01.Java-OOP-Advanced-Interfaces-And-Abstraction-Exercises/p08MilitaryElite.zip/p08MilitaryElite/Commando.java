package p08MilitaryElite;

import java.util.List;

public interface Commando extends SpecialisedSoldier {
    List<Mission> getMissions();
}
