package p08MilitaryElite;

import java.util.List;

public interface LeutenantGeneral extends Private {
    List<Private> getPrivates();
}
