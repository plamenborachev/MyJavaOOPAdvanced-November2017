package p08MilitaryElite;

import java.util.List;

public interface Engineer extends SpecialisedSoldier {
    List<Repair> getRepairs();
}
