package cresla.models.module;

public class CooldownSystem extends AbstractAbsorbingModule {

    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
