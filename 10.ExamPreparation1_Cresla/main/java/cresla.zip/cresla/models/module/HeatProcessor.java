package cresla.models.module;

import cresla.interfaces.AbsorbingModule;

public class HeatProcessor extends AbstractAbsorbingModule {

    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
