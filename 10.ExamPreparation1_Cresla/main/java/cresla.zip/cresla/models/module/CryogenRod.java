package cresla.models.module;

public class CryogenRod extends AbstractEnergyModule{

    public CryogenRod(int id, int energyOutput) {
        super(id, energyOutput);
    }
}
