package logger.contracts;

public interface ILayoutFactory {
    Layout getLayout(String type);
}
