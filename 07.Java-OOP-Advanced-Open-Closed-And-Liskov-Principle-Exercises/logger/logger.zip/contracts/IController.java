package logger.contracts;

public interface IController {
    void run();
}
