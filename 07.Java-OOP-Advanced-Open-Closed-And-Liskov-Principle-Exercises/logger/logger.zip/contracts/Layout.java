package logger.contracts;

public interface Layout {
    String getFormat();

}
