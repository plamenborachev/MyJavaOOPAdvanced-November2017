package logger.contracts;

public interface IConsoleInputReader {
    String readLine();
}
