package logger.io;

public class ConsoleOutputWriter  {

    public static void writeLine(String msg) {
        System.out.println(msg);
    }
}
