package hell.entities.heros;

import hell.interfaces.Inventory;

public class Barbarian extends BaseHero {

    public Barbarian(String name, String type, Inventory inventory) {
        super(name, type, inventory);
    }
}
