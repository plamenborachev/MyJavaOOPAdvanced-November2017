package hell.entities.heros;

import hell.interfaces.Inventory;

public class Assassin extends BaseHero {

    public Assassin(String name, String type, Inventory inventory) {
        super(name, type, inventory);
    }
}
