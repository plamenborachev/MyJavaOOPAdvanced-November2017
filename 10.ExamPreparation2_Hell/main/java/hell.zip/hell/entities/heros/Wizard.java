package hell.entities.heros;

import hell.interfaces.Inventory;

public class Wizard extends BaseHero {

    public Wizard(String name, String type, Inventory inventory) {
        super(name, type, inventory);
    }
}
